; ════════════════════════════════════════════════════════
;   CNCS · 校园网自动登录工具  v0.5
;   Campus Network Connection System
;   （校园网自动连接助手 · 取首字母，去掉 self）
;   AutoHotkey v2 脚本
;
;   制作：夏日花猫（Summer Calico）× 元宝AI
;         元宝AI（Yuanbao）
;   联合制作 · 2026
; ════════════════════════════════════════════════════════

; ↓↓↓ 以下指令仅在「编译成 EXE」时生效，正常运行脚本时是普通注释 ↓↓↓
;@Ahk2Exe-SetName CNCS 校园网自动登录工具
;@Ahk2Exe-SetDescription CNCS · Campus Network Connection System｜夏日花猫（Summer Calico）× 元宝AI × 元宝AI 联合制作
;@Ahk2Exe-SetVersion 0.5.0.0
;@Ahk2Exe-SetCompanyName （学校名已移除）
;@Ahk2Exe-SetCopyright Copyright (c) 2026 Summer Calico & Yuanbao AI
;@Ahk2Exe-SetOrigFilename CNCS校园网自动登录工具.exe

#Requires AutoHotkey v2.0
#SingleInstance Force
DetectHiddenWindows(true)
SetTitleMatchMode(2)
SetControlDelay(0)
SetWinDelay(0)

; ================== 配置区 ==============================
ClientPath   := "C:\Drcom\DrUpdateClient\DrMain.exe"   ; 校园网客户端路径
ClientExe    := "DrMain.exe"      ; 客户端进程名（按进程识别，弹窗标题叫什么都能抓到）
SaveFile     := A_ScriptDir "\account.ini"             ; 明文保存，转发前务必删除！
BusyEvery    := 1000    ; 有客户端窗口时扫描间隔(ms)
IdleEvery    := 5000    ; 空闲时扫描间隔(ms)
OkCooldown   := 2500    ; 点"确定"后冷却(ms)
LoginCooldown := 10000  ; 点"登录"后冷却(ms)
OnlineWords  := ""      ; 若登录后窗口出现"注销/已连接"等词，填进来可避免重复点登录

; 需要自动点“确定”的弹窗关键词（遇到新弹窗，把上面的字加进这个列表即可）
OkWords := ["断开", "异常", "已在线", "在线时长", "超时", "失败",
            "错误", "重新登录", "掉线", "限制", "已达"]

; ── 快捷键（可随便改！和别的软件冲突就换一个）────────────
;   写法：^ = Ctrl，! = Alt，+ = Shift，# = Win
;   例子：^2=Ctrl+2   !2=Alt+2   ^!s=Ctrl+Alt+S   F7=就是F7
;   想彻底禁用某个键：把等号后面清空即可（不占用任何按键）
Hotkey_SetAccount := "F7"    ; 设置账号密码（唯一占用的键，F7 在桌面/浏览器几乎无默认功能）
Hotkey_Quit       := ""      ; 退出热键已关闭，退出请右键托盘图标 →「退出脚本」
; ========================================================

; ================== 署名（关于窗口用）====================
AppName   := "CNCS 校园网自动登录"
AppVer    := "v0.5"
AppAuthor := "夏日花猫（Summer Calico）× 元宝AI"
AppAI     := "元宝AI（Yuanbao）"
; ========================================================

g_lastOk := 0
g_lastLogin := 0
g_askOpen := false
g_aboutOpen := false
g_askGui := ""      ; 账号设置窗口对象
g_askEdU := ""      ; 账号输入框
g_askEdP := ""      ; 密码输入框
g_aboutGui := ""    ; 关于窗口对象

; ================== 配置自动备份 / 自愈恢复 ==================
; 即使整个安装文件夹被误删，账号密码也能自动找回来
BackupDir  := A_AppData "\AutoCampusNet"
BackupFile := BackupDir "\account.ini.bak"

if FileExist(SaveFile) {
    ; 有配置 -> 同步备份一份（始终保持最新）
    try {
        DirCreate(BackupDir)
        FileCopy(SaveFile, BackupFile, true)
    }
} else if FileExist(BackupFile) {
    ; 配置没了但备份还在 -> 自动恢复，用户无感知
    try {
        FileCopy(BackupFile, SaveFile, false)
        try TrayTip("已自动恢复上次保存的账号配置", AppName, 1)
    }
}
; ============================================================
g_idle := 0
g_period := 0

; —— 开机自启 ——
linkPath := A_Startup "\CNCS 校园网自动登录.lnk"
if !FileExist(linkPath) {
    try RunWait('powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut(\"' linkPath '\"); $s.TargetPath = \"' A_ScriptFullPath '\"; $s.Save()"')
}

; —— 管理员提权（首次弹一次 UAC）——
if !A_IsAdmin {
    try Run('*RunAs "' A_ScriptFullPath '"')
    ExitApp()
}

; —— 托盘图标（同目录 app.ico = 向日葵，高中时画的）——
icoFile := A_ScriptDir "\app.ico"
if FileExist(icoFile) {
    try TraySetIcon(icoFile)
}

; —— 托盘菜单 ——
A_TrayMenu.Delete()
A_TrayMenu.Add("打开客户端", (*) => OpenClient())
A_TrayMenu.Add("设置账号密码", (*) => AskAccount())
A_TrayMenu.Add("关于本工具", (*) => ShowAbout())
A_TrayMenu.Add()
A_TrayMenu.Add("退出脚本", (*) => ExitApp())
A_TrayMenu.Default := "打开客户端"

; 说明内容全部写在 1-说明书【重点看】/使用说明.txt，脚本不再弹说明书窗口

SetTimer(CheckWindows, BusyEvery)

; —— 还没设过账号？提醒按 F7 ——
if (ReadIni("Account", "User", "") = "") {
    ; 启动 3 秒后飘一句提醒，18 秒后自动收掉气泡
    SetTimer(ShowFirstRemind, -3000)
    SetTimer(HideRemind, -18000)
}

; 首次提醒：还没设过账号
ShowFirstRemind() {
    try TrayTip("还没设置账号密码呢`n按 " KeyName(Hotkey_SetAccount) " 填一次，之后就全自动了", AppName, 1)
}

; 让气泡自己消失，不一直挂着
HideRemind() {
    try TrayTip()
}

; 快捷键（按上面配置区 Hotkey_SetAccount / Hotkey_Quit 注册）
; 改成空字符串即可禁用，不会占用任何按键
if (Hotkey_SetAccount != "") {
    try
        Hotkey(Hotkey_SetAccount, (*) => AskAccount())
}
if (Hotkey_Quit != "") {
    try
        Hotkey(Hotkey_Quit, (*) => ExitApp())
}

; ============ 打开客户端 ============
OpenClient() {
    try
        Run(ClientPath)
    catch
        MsgBox("打开客户端失败，请检查路径：`n" ClientPath, "自动校园网", 48)
}

; ============ 后台自动处理 ============
CheckWindows(*) {
    global g_idle, g_period
    ; 快速预判：无目标窗口直接返回（极省资源）
    ; 按进程名判断：弹窗标题是"提示""警告"等也不会漏
    if !WinExist("ahk_exe " ClientExe) && !WinExist("某某大学") && !WinExist("网络选择") {
        g_idle++
        if (g_idle > 20 && g_period != IdleEvery) {
            SetTimer(CheckWindows, IdleEvery)
            g_period := IdleEvery
        }
        return
    }
    g_idle := 0
    if (g_period != BusyEvery) {
        SetTimer(CheckWindows, BusyEvery)
        g_period := BusyEvery
    }

    for id in WinGetList() {
        try title := WinGetTitle(id)
        catch
            continue
        if (title = "")
            continue
        ; 按进程名识别：弹窗标题可能是"提示""警告"等，只看标题会漏
        if !IsClientWindow(id, title)
            continue
        idStr := "ahk_id " id
        texts := GetWinText(id)

        ; A. 各类提示弹窗（断线/异常/已在线/超时/失败…）-> 点"确定"
        needOk := false
        for w in OkWords {
            if InStr(texts, w) {
                needOk := true
                break
            }
        }
        if needOk || InStr(title, "网络选择") {
            ClickOk(idStr)
            continue
        }
        ; B. 登录界面 -> 填号/勾选/登录
        if InStr(texts, "密码") || HasCtrl(id, "Edit2")
            HandleLogin(idStr, texts)
    }
}

; 把 AHK 热键写法转成给人看的文字（^2 -> Ctrl+2，F7 -> F7）
KeyName(hk) {
    if (hk = "")
        return "（已禁用）"
    s := ""
    if InStr(hk, "^")
        s .= "Ctrl+"
    if InStr(hk, "!")
        s .= "Alt+"
    if InStr(hk, "+")
        s .= "Shift+"
    if InStr(hk, "#")
        s .= "Win+"
    key := StrReplace(hk, "^")
    key := StrReplace(key, "!")
    key := StrReplace(key, "+")
    key := StrReplace(key, "#")
    return s key
}

; 判断窗口是否属于校园网客户端（优先按进程名，标题兜底）
IsClientWindow(winId, title) {
    try {
        if InStr(WinGetProcessName(winId), StrReplace(ClientExe, ".exe"))
            return true
    }
    if InStr(title, "某某大学") || InStr(title, "网络选择")
        return true
    return false
}

; 取窗口文本：可见用快方式，最小化才用慢的控件枚举
GetWinText(id) {
    if WinGetMinMax(id) != -1 {
        try
            t := WinGetText(id)
        catch
            t := ""
        if (t != "")
            return t
    }
    return GetCtrlTexts(id)
}

GetCtrlTexts(winId) {
    txt := ""
    try
        for h in WinGetControlsHwnd(winId)
            try txt .= ControlGetText(h) "`n"
    return txt
}

HasCtrl(winId, classNN) {
    try {
        ControlGetHwnd(classNN, "ahk_id " winId)
        return true
    } catch
        return false
}

; ============ 登录界面处理 ============
HandleLogin(idStr, texts) {
    ; 已登录标志 -> 不动
    if (OnlineWords != "" && RegExMatch(texts, "(" OnlineWords ")"))
        return

    cur := ReadAccount(idStr)
    pwd := ReadPassword(idStr)

    ; ① 界面已有账号 -> 记住并直接登录
    if Trim(cur) != "" {
        if IsValidUser(cur)
            WriteIni("Account", "User", cur)
        if IsRealPwd(pwd)
            WriteIni("Account", "Pass", pwd)
        EnsureCheck(idStr)
        ClickLogin(idStr)
        return
    }
    ; ② 账号为空 -> 用记住的自动填
    savedUser := ReadIni("Account", "User", "")
    savedPass := ReadIni("Account", "Pass", "")
    if (savedUser = "")
        return
    if (savedPass = "") {
        AskAccount()
        return
    }
    FillAccount(idStr, savedUser, savedPass)
    EnsureCheck(idStr)
    ClickLogin(idStr)
}

FillAccount(idStr, user, pass) {
    try
        ControlSetText(user, "Edit1", idStr)
    catch
        try ControlSetText(user, "ComboBox1", idStr)
    Sleep(150)
    try
        ControlSetText(pass, "Edit2", idStr)
    catch {
        try ControlClick("Edit2", idStr)
        Sleep(100)
        try ControlSend(pass, "Edit2", idStr)
    }
    Sleep(200)
}

ReadAccount(idStr) {
    v := ""
    try v := ControlGetText("Edit1", idStr)
    catch
        try v := ControlGetText("ComboBox1", idStr)
    return v
}
ReadPassword(idStr) {
    v := ""
    try v := ControlGetText("Edit2", idStr)
    return v
}
IsValidUser(u) {
    return RegExMatch(u, "^\d{5,20}$")     ; 纯数字账号
}
IsRealPwd(p) {
    return (p != "" && !RegExMatch(p, "^\*+$") && StrLen(p) <= 32)
}

; 勾选"记住密码""自动登录"（已勾绝不动）
EnsureCheck(idStr) {
    for lb in ["记住密码", "自动登录"] {
        try {
            if ControlGetChecked(lb, idStr) = 0 {
                ControlClick(lb, idStr)
                Sleep(150)
            }
        }
    }
}

; 点"确定"（带冷却）
ClickOk(idStr) {
    global g_lastOk
    if (A_TickCount - g_lastOk < OkCooldown)
        return
    try ControlClick("确定", idStr)
    catch
        try ControlClick("Button1", idStr)
    g_lastOk := A_TickCount
}

; 点"登录"（带冷却）
ClickLogin(idStr) {
    global g_lastLogin
    if (A_TickCount - g_lastLogin < LoginCooldown)
        return
    try ControlClick("登录", idStr)
    catch
        try ControlClick("Button1", idStr)
    g_lastLogin := A_TickCount
}

; ============ Ini 读写（全程容错）============
ReadIni(sec, key, def := "") {
    try
        return IniRead(SaveFile, sec, key, def)
    catch
        return def
}
WriteIni(sec, key, val) {
    try IniWrite(val, SaveFile, sec, key)
}

; ============ 设置账号密码（F7 / 缺密码自动弹）============
AskAccount() {
    global g_askOpen, g_askGui, g_askEdU, g_askEdP
    if g_askOpen
        return
    g_askOpen := true
    g := Gui("+AlwaysOnTop +ToolWindow", "校园网账号设置")
    g.SetFont("s10", "Microsoft YaHei")
    g.Add("Text", "x16 y16", "账号：")
    edU := g.Add("Edit", "x70 y12 w210", ReadIni("Account", "User", ""))
    g.Add("Text", "x16 y48", "密码：")
    edP := g.Add("Edit", "x70 y44 w210 Password", ReadIni("Account", "Pass", ""))
    g.Add("Text", "x16 y80 cGray", "仅存本机 account.ini，转发前请先删除此文件")
    btn := g.Add("Button", "x70 y108 w100 Default", "保存")
    g_askGui := g
    g_askEdU := edU
    g_askEdP := edP
    btn.OnEvent("Click", (*) => SaveAccount())
    g.OnEvent("Close", (*) => CloseAskAccount())
    g.Show("AutoSize Center")
}

; 点「保存」：把账号密码写进 account.ini
SaveAccount(*) {
    global g_askOpen, g_askGui, g_askEdU, g_askEdP
    WriteIni("Account", "User", g_askEdU.Value)
    WriteIni("Account", "Pass", g_askEdP.Value)
    g_askOpen := false
    if IsObject(g_askGui)
        g_askGui.Destroy()
}

; 直接关掉设置窗口
CloseAskAccount(*) {
    global g_askOpen
    g_askOpen := false
}

; ============ 关于本工具（署名）============
ShowAbout() {
    global g_aboutOpen, g_aboutGui
    if g_aboutOpen
        return
    g_aboutOpen := true
    g := Gui("+AlwaysOnTop +ToolWindow", "关于 " AppName)
    g.SetFont("s11 Bold", "Microsoft YaHei")
    g.Add("Text", "w460 Center", AppName "  " AppVer)
    g.SetFont("s9 Norm", "Microsoft YaHei")
    g.Add("Text", "w460 Center cGray", "Campus Network Connection System")
    g.Add("Text", "w460 Center cGray", "AutoHotkey v2 · Windows 校园网自动登录")
    g.Add("Text", "w460", "
(
────────────────────────────────────────
【制作团队】

  夏日花猫
  夏日花猫 × 元宝AI

  ×

  元宝AI（Yuanbao）
  腾讯智能助手

        —— 联合制作 ——
────────────────────────────────────────

  感谢使用！愿你的校园网永不掉线。

  ⚠️ 安全提醒：账号密码明文保存在
     account.ini，转发前务必删除！
)")
    btn := g.Add("Button", "w100 Center Default", "好")
    g_aboutGui := g
    btn.OnEvent("Click", (*) => CloseAbout())
    g.OnEvent("Close", (*) => CloseAbout())
    g.Show("AutoSize Center")
}

; 关掉「关于」窗口
CloseAbout(*) {
    global g_aboutOpen, g_aboutGui
    g_aboutOpen := false
    if IsObject(g_aboutGui)
        g_aboutGui.Destroy()
}
