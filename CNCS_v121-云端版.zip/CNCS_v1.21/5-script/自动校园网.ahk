; ════════════════════════════════════════════════════════
;   CNCS · 校园网自动登录工具  v1.21
;   Campus Network Connection System
;   （校园网自动连接助手 · 取首字母，去掉 self）
;   AutoHotkey v2 脚本
;
;   制作：江西赣南科技学院 通信 夏日花猫（Summer Calico）
;         元宝AI（Yuanbao）
;   联合制作 · 2026
; ════════════════════════════════════════════════════════

; ★ 本工具【不提供也不编译 EXE】，只以 .ahk 源码形式分发。
;   原因：AHK 编译本质是把解释器+脚本打包成一个二进制文件，
;   跟部分恶意软件的打包方式一样，360/火绒/Defender 等
;   误报概率大幅上升，徒增用户困扰（详见 1-manual/杀软报毒说明.txt）。
;   因此这里【故意不写】任何 @Ahk2Exe-* 编译指令 ——
;   留着只会误导人去"右键编译"，反而制造问题。
;   想确认它没毒？用记事本打开本文件，每一行都是明文。

#Requires AutoHotkey v2.0
#SingleInstance Force
DetectHiddenWindows(true)
SetTitleMatchMode(2)
SetControlDelay(0)
SetWinDelay(0)

; ================== 配置区 ==============================
ClientPath   := "C:\Drcom\DrUpdateClient\DrMain.exe"   ; 校园网客户端完整路径（装的地方不同就改这里）
ClientExe    := "DrMain.exe"      ; 客户端进程名（按进程识别，弹窗标题叫什么都能抓到）
ClientTitle  := "江西理工大学"    ; 客户端窗口标题里的学校名（抓弹窗用；换学校必改这一行）
                                  ; 找不到窗口标题时，打开客户端看标题栏写的是什么，照抄进来
SaveFile     := A_ScriptDir "\account.ini"             ; 明文保存，转发前务必删除！
BusyEvery    := 1000    ; 有客户端窗口时扫描间隔(ms)
IdleEvery    := 5000    ; 空闲时扫描间隔(ms)
OkCooldown   := 2500    ; 点"确定"后冷却(ms)
LoginCooldown := 10000  ; 点"登录"后冷却(ms)
LaunchCooldown := 60000 ; 客户端不在跑时，隔多久帮你重新拉起一次(ms)，60000=1分钟
CloseGraceSec := 45     ; 你手动关掉客户端后，观察多少秒才确认"是你关的"(秒)
                        ;   给一点宽限是因为：客户端自己更新/重启时会短暂消失，
                        ;   等一会儿它自己回来，脚本就不打扰你；超过这个时间还没回来，
                        ;   才认定"用户关了"，此后【不再自动拉起】，直到你按 Ctrl+Alt+F9。
OnlineWords  := ""      ; 若登录后窗口出现"注销/已连接"等词，填进来可避免重复点登录
AskCooldown  := 300000 ; 密码没填时，自动弹账号窗口的冷却(ms)，300000=5分钟
                       ;   不设冷却的话，脚本每秒扫描一次就会每秒弹一次窗
CalmEvery    := 3000    ; 稳态扫描间隔(ms)：一切正常、没活可干时的省电模式
CalmAfter    := 15      ; 连续多少轮"没活干"才进入稳态（BusyEvery=1s → 约 15 秒）
                       ;   一旦有弹窗要处理，立刻恢复 1 秒快扫，不影响响应速度

; ── 防遮挡 / 通知（新增，可关）────────────────────────────
;  窗口被别的软件盖住时脚本照样能点（ControlClick 不需要窗口可见）。
;  只有"最小化到任务栏"才可能点不动，下面这个开关就是防它的：
;  发现最小化就把它恢复回来，但【不抢焦点】，不会打断你打游戏/打字。
EnsureVisible   := true     ; true=自动恢复最小化窗口（不激活）；false=不管
NotifyReconnect := true     ; true=断线重连成功后右下角飘一句提示；false=不提示

; ── 关掉客户端自己弹的"文档"窗口（1.21 新增）────────────
;  部分 Drcom 客户端（DrMain.exe）启动时会顺手打开一个"文档"
;  文件夹窗口 —— 那是客户端自带的动作，不是脚本干的关不掉。
;  开着它容易挡住桌面，脚本帮你自动关掉。
CloseClientDoc := true      ; true=自动关掉；false=让它弹着不管
ClientDocTitle := "文档"    ; 那个窗口的标题（按你实际看到的填，支持部分匹配）
DocCloseDelay  := 1500      ; 拉起客户端后等多少毫秒再去关（太早了窗口还没弹出来）
DocGraceSec    := 15        ; 只关"刚拉起客户端后"这段时间内出现的窗口
                            ;   防止误关你自己打开的文档文件夹；每次拉起只关一次

; ── 客户端拉起 / 提权（1.0 新增）──────────────────────────
;  客户端不在跑时，脚本就没事可做。下面控制"要不要帮你把它拉起来"。
; ── 用不用校园网，让你来决定（1.0 修订）──────────────────
;  在家 / 校外连别的网时，客户端拉起来也登不上，一直挂着只会烦人。
;  所以：不擅自替你开客户端，由你按 Ctrl+Alt+F9 决定。
;
;    ★ 按了 Ctrl+Alt+F9  = 这次要用校园网 → 拉起客户端、开始自动登录
;    ★ 没按 Ctrl+Alt+F9  = 在用别的网    → 客户端保持不开，脚本静默待命
;                                 下次开机重新识别一次
;
;  注意：不再"拉起又自动关掉"（那样在学校忘按 Ctrl+Alt+F9 反而会断网）。
;  现在没按就是不开，干干净净。
; ── 长期工作模式（1.05 改版）────────────────────────────
;  这是【唯一】的工作方式，不再有"每次开机都等你按 Ctrl+Alt+F9"那种模式。
;  它记的是你的使用习惯，规则只有三条：
;
;    ① 你用过一次（按过 Ctrl+Alt+F9）      → 以后开机自动打开，不用管
;    ② 你主动关掉了它              → 记下来，【下次开机问你一句】再决定
;    ③ 你点了"打开"               → 恢复自动，回到 ①
;
;  这样既不会自作主张把你关掉的东西拉回来，也不用每次开机手动按。
RememberOnCampus := (ReadIni("Config", "RememberOnCampus", "1") = "1")
                          ; true  = 长期工作模式（默认）
                          ; false = 完全手动，只在按 Ctrl+Alt+F9 时才开（一般不用改）
                          ; ★ 日常不用改这里 —— 想停用就用托盘「停止客户端」

Lang := ReadIni("Config", "Lang", "zh")
                          ; 界面语言：zh=中文 / en=English
                          ; ★ 不用改这里 —— 右键托盘「语言 / Language」随时切换
LoadLang(Lang)

; ── 首次运行弹窗说明（1.0 新增）──────────────────────────
;  第一次打开时弹一个窗口，讲清楚两个按键是干嘛的。
;  只弹一次，看完记住；之后想再看，托盘菜单里有。
ShowGuideOnFirstRun := true  ; true=首次运行弹一次按键说明；false=从不弹

AutoStartClient   := true   ; true=脚本启动后自动拉起客户端；false=只等你手动/按热键

; ── "要不要按 Ctrl+Alt+F9" 定时提醒 ────────────────────────────────
;  没确认在校时，隔一会儿飘一句问你要不要开客户端，免得开机忙着别的事
;  就把这事忘了、结果校园网一直没连上。
RemindF9          := true   ; true=定时提醒；false=从不提醒（只在你按 Ctrl+Alt+F9 时才开）
RemindF9First     := 8000   ; 启动后多久提醒第一次（毫秒，8000=8秒）
RemindF9Every     := 180000 ; 之后每隔多久提醒一次（毫秒，180000=3分钟）
RemindF9Times     := 3      ; 最多提醒几次（按了 Ctrl+Alt+F9 就立刻停）
                            ; 提醒到次数还不开 → 判定你在用别的网，不再打扰

; ★ 关键：默认【开启管理员提权】。这跟能跑通的 v0.5 一致，别轻易关掉。
;   绝大多数校园网客户端（Dr.COM / 锐捷 / 城市热点等）都要管理员权限。
;   脚本自己不是管理员时，会出两个问题：
;     ① 拉起客户端被 UAC 框挡住 → 按 Ctrl+Alt+F9 没反应
;     ② 就算它起来了，Windows 的 UIPI 机制让普通权限的程序
;        点不动管理员权限的窗口 → 自动填号、点登录全失效
;   所以让脚本和客户端【权限一致】才是正解。
RequireAdmin      := true   ; true=启动时弹一次 UAC 提权（默认，推荐）
                            ; false=静默以普通权限启动
                            ;   ★ 只有确认你的客户端【不需要】管理员权限时才改 false
                            ;     判断方法：手动双击客户端，看弹不弹 UAC 框。
                            ;     弹了 → 保持 true；没弹 → 可改 false 省掉那次 UAC
; ── UAC 拦截 / 提权（1.0 新增）──────────────────────────────
;  很多校园网客户端（Dr.COM 等）需要管理员权限，启动时 Windows 会弹
;  UAC 确认框。脚本是普通权限时，弹框不去点，客户端就起不来；
;  就算它提权跑起来了，还有第二层坑 —— UIPI（界面特权隔离）：
;  普通权限的脚本，点不动管理员权限的客户端窗口，自动登录会失效。
;
;  ★ 所以解决办法是：让脚本和客户端【权限一致】。
;    两个入口，都在托盘右键菜单里：
;      ①「以管理员权限重启」—— 立刻变管理员，之后 Ctrl+Alt+F9 直接拉起、也能点它
;                                （这次会弹一次 UAC，点确定即可）
;      ②「开机自启：改用计划任务」—— 以后开机自动以管理员权限启动，
;                                且不弹 UAC（一次性授权，之后永久静默）
;
;  判断你的客户端要不要管理员：手动双击它，看有没有弹 UAC 框。
;  弹了 → 用上面两个入口；没弹 → 什么都不用改。

; 需要自动点“确定”的弹窗关键词（遇到新弹窗，把上面的字加进这个列表即可）
OkWords := ["断开", "异常", "已在线", "在线时长", "超时", "失败",
            "错误", "重新登录", "掉线", "限制", "已达"]

; ── 客户端弹窗的【通用标题】（v1.21 补）──────────────────
;  很多客户端弹窗标题就叫「提示」「警告」—— 既不带学校名，
;  也【不属于】客户端主进程（自己另起一个进程弹出来的），
;  于是按进程名、按学校名都抓不到它，脚本就一直不点。（真机遇到：
;  「已在线60分钟」那个「提示」框就是这么漏掉的）
;  所以这里按通用标题兜底补扫。
;
;  ★ 三重保险，不会误点别的软件：
;    ① 窗口类必须是 #32770（Windows 标准对话框，也就是 MessageBox）
;       —— 网页、编辑器、聊天窗口都不是这个类，直接排除
;    ② 只在【客户端确实在跑】时才扫（见 CheckWindows 开头的快速预判）
;    ③ 仍然要过上面 OkWords 的关键词过滤，命中才点“确定”
PromptTitles := ["提示", "警告", "错误", "信息", "注意", "消息"]

; 其中【真正算掉过线】的词（其余只是普通提醒，不记成掉线）
;  ★ 为什么要分开：「已在线60分钟」这类只是时长提醒，并没有掉线。
;    混在一起的话，下次登录会误飘一句「已自动重连」。（v1.21 修复）
DropWords := ["断开", "异常", "超时", "失败", "错误", "重新登录", "掉线"]

; ── 快捷键（可随便改！和别的软件冲突就换一个）────────────
;   写法：^ = Ctrl，! = Alt，+ = Shift，# = Win
;   例子：^2=Ctrl+2   !2=Alt+2   ^!s=Ctrl+Alt+S   F7=就是F7
;   想彻底禁用某个键：把等号后面清空即可（不占用任何按键）
; ★ 默认用【组合键】而不是纯功能键，理由见下方注释
;   AHK 写法：^ = Ctrl，! = Alt，+ = Shift，# = Win
;
; ── 想用【字母键】？（v1.21 新增，大小写全认）──────────────
;   ★ 写小写就行，比如 ^!s（= Ctrl+Alt+S）
;   ★ 按的时候【y 和 Y 都认】，不用管大小写，也不用管 CapsLock。
;     脚本会自动把「不带 Shift」和「带 Shift」两个版本都注册上，
;     所以你按 Ctrl+Alt+S 或 Ctrl+Alt+Shift+S，都一样触发。
;   ★ 中文输入法【不影响】热键：
;     AHK 拦的是【物理按键】，跟你当时打出的是「月」还是 "y" 无关。
;     中文状态下按 Ctrl+Alt+S 照样触发。
;     （唯一例外：如果输入法自己占用了这个组合，比如把它设成了
;       切换输入法的快捷键 —— 去输入法设置里改掉即可。）
;
;   ⚠️ 但【千万别用裸字母】（不加 Ctrl/Alt 直接写 "s"）：
;      那样你打字每按一次 s 都会弹窗，等于没法正常打字了。
;      至少带一个修饰键，比如 ^!s / !s / ^s。
;
;   默认用组合键 = Ctrl+Alt+F7 / Ctrl+Alt+F9（见下方说明）
Hotkey_SetAccount := "^!F7"  ; 设置账号密码
Hotkey_OpenClient := "^!F9"  ; 手动拉起校园网客户端

; 为什么不用单纯的 F7 / F9（1.20 定稿）：
;   Windows 的全局热键是【独占】的 —— 谁先启动谁占住，
;   后启动的那个按了【完全没反应】，而且不报错、不提示。
;   游戏辅助工具（BetterGI 之类）喜欢把 F6~F12 整段注册成全局热键，
;   两边一起开就会有一边失灵，表现为"软件莫名坏了"。
;   Ctrl+Alt+F7/Ctrl+Alt+F9 这种组合键几乎没人占，跟任何工具都不打架。
;   想改回纯功能键就把上面两行改成 "F7" / "F9"（托盘说明会自动跟着变）。
Hotkey_Quit       := ""      ; 退出热键已关闭，退出请右键托盘图标 →「退出脚本」
; ========================================================

; ================== 署名（关于窗口用）====================
AppName   := "CNCS 校园网自动登录"
AppVer    := "v1.21"
AppAuthor := "江西赣南科技学院 通信 夏日花猫（Summer Calico）"
AppAI     := "元宝AI（Yuanbao）"
; ========================================================

; ── 常量区（必须放在最前面的自动执行段，别往后挪！）──────
;  这些是脚本运行前就要准备好的常量。
;  AHK 是【从上往下】执行顶层语句的，如果常量赋值写在后面，
;  而某个函数在上面就被调用了，就会报变量未赋值 —— 顺序很重要。
AutoTaskName := "CNCS-AutoStart"   ; 提权自启计划任务的名字

g_lastOk := 0
g_lastLogin := 0
g_askOpen := false
g_guideGui := 0
g_aboutOpen := false
g_askGui := ""      ; 账号设置窗口对象
g_askEdU := ""      ; 账号输入框
g_askEdP := ""      ; 密码输入框
g_aboutGui := ""    ; 关于窗口对象

g_netWasDown := false   ; 是否刚经历了一次断线（用于重连成功提示）
g_lastLaunch := 0       ; 上次尝试拉起客户端的时间戳（防频繁启动）
g_lastAsk    := 0       ; 上次【自动】弹账号窗口的时间戳（防每秒弹窗刷屏）
g_calm       := 0       ; 连续多少轮"没活干"（达到上限就降频省资源）

; ★ 进程名去掉 .exe 只算一次，别在每个窗口、每一轮里反复 StrReplace
ClientExeBase := StrReplace(ClientExe, ".exe")

g_confirmed  := false   ; 是否已确认在校（按了 Ctrl+Alt+F9，或记忆模式已记住"在校"）
g_remindCount := 0      ; 已经提醒过几次"要不要按 Ctrl+Alt+F9"（到上限就停）
g_guideOpen  := false   ; 按键说明弹窗是否开着（防重复弹出）
g_stopped    := false   ; 用户主动停了客户端 → 不许再自动拉起（除非再按一次 Ctrl+Alt+F9）
g_clientSeen := false   ; 客户端这一轮【跑起来过】（用来判断"从有到无"才是被关掉）
g_closeAt    := 0       ; 第一次发现客户端消失的时间戳（0=在跑 / 或还没开始观察）
g_launchFail := 0       ; 连续拉起失败次数（路径写错时防止一直重试刷屏）
g_pathWarned := false   ; 路径无效这事只提醒一次，不反复烦人
g_launchTick := 0       ; 上次【成功】拉起客户端的时间戳（关"文档"窗口用）
g_docClosed  := false   ; 本次拉起是否已经关过"文档"窗口（只关一次，不重复打扰）

; ============ 安装标记 cncs.id（自报家门）============
; 每次启动都写一次，相当于给这个安装"上户口"。
; · 人肉排查时一眼看清：装在哪、哪一版、主脚本是谁
; · 只含路径和版本，【不含账号密码】—— 转发分享时不用删
; · 放在这里尽早写入，保证后续逻辑出错也有标记留下
MarkerFile := A_ScriptDir "\cncs.id"
try {
    marker := "CNCS Campus Network Connection System`n"
            . "Identity=CNCS`n"
            . "Version=" AppVer "`n"
            . "InstallPath=" A_ScriptDir "`n"
            . "ScriptFile=" A_ScriptFullPath "`n"
            . "Updated=" FormatTime(, "yyyy-MM-dd HH:mm") "`n"
    FileDelete(MarkerFile)
    FileAppend(marker, MarkerFile, "UTF-8")
}

; ================== 配置自动备份 / 自愈恢复 ==================
; 即使整个安装文件夹被误删，账号密码也能自动找回来
BackupDir  := A_AppData "\AutoCampusNet"
BackupFile := BackupDir "\account.ini.bak"

if FileExist(SaveFile) {
    ; 有配置 -> 同步备份一份（始终保持最新）
    try {
        DirCreate(BackupDir)
        FileCopy(SaveFile, BackupFile, true)
    }
} else if FileExist(BackupFile) {
    ; 配置没了但备份还在 -> 自动恢复，用户无感知
    try {
        FileCopy(BackupFile, SaveFile, false)
        try TrayTip(L("tip_restore"), AppName, 1)
    }
}
; ============================================================

g_idle := 0
g_period := 0

; —— 开机自启 ——
; 延后 3 秒再建，并且异步执行：
; powershell 冷启动要 1~2 秒，同步等待会把首屏的托盘/定时器全拖慢。
linkPath := A_Startup "\CNCS.lnk"
if !FileExist(linkPath)
    SetTimer(MakeStartupLink, -3000)

MakeStartupLink() {
    lp := A_Startup "\CNCS.lnk"
    if FileExist(lp)
        return
    try RunWait('powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut(\"' lp '\"); $s.TargetPath = \"' A_ScriptFullPath '\"; $s.WorkingDirectory = \"' A_ScriptDir '\"; $s.Save()"')
}

; —— 管理员提权 ——
; 做法取自能跑通的 v0.5：启动即以管理员权限运行。
; 这样拉客户端不会被 UAC 挡、也点得动它的窗口（避开 UIPI）。
; 提权成功后会启动一个新的管理员实例，本实例随即退出；
; 那个新实例里 A_IsAdmin=true，不会再走这里，所以不会循环。
if (RequireAdmin && !A_IsAdmin) {
    try {
        Run('*RunAs "' A_AhkPath '" "' A_ScriptFullPath '"')
        ExitApp()
    } catch {
        ; 用户点了"取消"→ 不能让脚本就这么打不开，
        ; 降级成普通权限继续跑，稍后飘一句提示说明影响。
        SetTimer(ShowAdminTip, -4000)
    }
}

; —— 托盘图标（同目录 app.ico = 向日葵，高中时画的）——
icoFile := A_ScriptDir "\app.ico"
if FileExist(icoFile) {
    try TraySetIcon(icoFile)
}

; —— 托盘菜单（切语言 / 切记忆开关时会整体重建）——
BuildTrayMenu()

; 说明内容全部写在 1-manual/使用说明.txt，脚本不再弹说明书窗口

SetTimer(CheckWindows, BusyEvery)

; —— 启动后要不要拉起客户端（延迟 5 秒，避开开机早期环境未就绪）——
; ★ 只有【已确认在校】才自动拉：
;     · 记忆模式已记住在校 → 直接拉起、自动登录，不用管
;     · 没记住 / 记忆模式关 → 【不拉起】，等你按 Ctrl+Alt+F9
;   这样在家永远不会被硬塞一个登不上的客户端。
if (AutoStartClient && RememberOnCampus && IsOnCampus()) {
    ; 上次是你自己关掉的 → 不擅自拉回来，先问一句（见 AskReopen）
    if (WasStopped())
        SetTimer(AskReopen, -6000)
    else
        SetTimer(AutoOpenClient, -5000)
} else {
    ; 没自动拉起 → 定时提醒可以按 Ctrl+Alt+F9
    ; 第一次快一点（8 秒），之后按 RemindF9Every 间隔循环，
    ; 达到 RemindF9Times 次就不再打扰（默认：8秒 → 3分 → 6分 → 收工）
    if RemindF9
        SetTimer(ShowPressTip, -RemindF9First)
}

; —— 还没设过账号？提醒按 Ctrl+Alt+F7 ——
if (ReadIni("Account", "User", "") = "") {
    ; 启动 3 秒后飘一句提醒，18 秒后自动收掉气泡
    SetTimer(ShowFirstRemind, -3000)
    SetTimer(HideRemind, -18000)
}

; —— 第一次打开？弹窗讲清楚两个按键 ——
; 只弹一次；看完写进配置，以后不再打扰。
; 想再看：右键托盘图标 →「查看按键说明」
if (ShowGuideOnFirstRun && ReadIni("State", "SeenGuide", "0") != "1") {
    SetTimer(ShowKeyGuide, -2000)
}

; ★ 统一的"拉起客户端"入口：三处（Ctrl+Alt+F9、开机自动、兜底保活）都走这里
;   · 路径不存在 → 提示一次，并停止后续自动重试（不然会一直刷屏）
;   · 成功 → 失败计数清零
LaunchClient(silent := false) {
    global g_launchFail, g_pathWarned, g_clientSeen, g_closeAt, g_launchTick, g_docClosed
    if !FileExist(ClientPath) {
        g_launchFail++
        if !g_pathWarned {
            g_pathWarned := true
            try TrayTip(L("err_nopath", ClientPath), AppName, 3)
        }
        return false
    }
    try {
        Run(ClientPath)
    } catch {
        g_launchFail++
        if (!silent && !g_pathWarned) {
            g_pathWarned := true
            try TrayTip(L("err_launch", ClientPath), AppName, 3)
        }
        return false
    }
    ; ★ 后台自动拉起时【不做下面的阻塞验证】，直接返回。
    ;   AHK 是单线程，这里 Sleep 等 6 秒会把定时器、热键、托盘全卡住；
    ;   兜底保活每分钟触发一次，就会变成"每分钟卡 6 秒"，按 Ctrl+Alt+F7/Ctrl+Alt+F9 没反应。
    ;   客户端起没起来，交给 CheckWindows 下一轮自然发现即可。
    ;   只有用户【主动按 Ctrl+Alt+F9】时才值得等一下，好给出准确反馈。（v1.21 修复）
    ; ★ 客户端拉起来了，过一会儿去关掉它自己弹的"文档"窗口（v1.21）
    ;   用一次性定时器，不在这里 Sleep —— Sleep 会把热键/托盘/定时器全卡住。
    g_launchTick := A_TickCount
    g_docClosed := false
    if CloseClientDoc
        SetTimer(CloseClientDocWindow, -DocCloseDelay)

    if silent {
        g_launchFail := 0     ; Run 已成功，之前攒的失败次数该清零
        g_clientSeen := true  ; 后台拉起也算"跑起来过"，之后被关才认得出
        g_closeAt := 0
        return true
    }
    ; ★ 启动后验证：最多等 6 秒看进程是否真的冒出来
    ;   被 UAC 框挡住的话，进程根本不会出现 —— 以前脚本却以为成功了，
    ;   于是你按了 Ctrl+Alt+F9 却什么都没发生，还查不出原因。
    loop 60 {
        Sleep(100)
        if ProcessExist(ClientExe) {
            g_launchFail := 0
            g_clientSeen := true   ; 记下"跑起来过"，之后被关掉才认得出
            g_closeAt := 0
            return true
        }
    }
    g_launchFail++
    if (!silent && !g_pathWarned) {
        g_pathWarned := true
        try TrayTip(L("err_uac", KeyName(Hotkey_OpenClient)), AppName, 3)
        SetTimer(HideRemind, -12000)
    }
    return false
}

; ── UAC / 提权 ──────────────────────────────────────────────
;  客户端需要管理员权限时的两个解法，详见配置区说明。
;  常量统一放在文件开头的【常量区】，别在这里赋值 ——
;  托盘菜单在上方就已经调用 AutoTaskExists()，赋值太晚会报
;  "This global variable has not been assigned a value"。

; 以管理员权限重启本脚本（弹一次 UAC，点确定即可）
RestartAsAdmin() {
    if A_IsAdmin {
        try TrayTip(L("tip_already_admin"), AppName, 1)
        SetTimer(HideRemind, -4000)
        return
    }
    try {
        Run('*RunAs "' A_AhkPath '" "' A_ScriptFullPath '"')
        ExitApp()
    } catch {
        try TrayTip(L("err_admin_fail"), AppName, 3)
        SetTimer(HideRemind, -8000)
    }
}

; 提权自启计划任务在不在（用 schtasks 查）
AutoTaskExists() {
    global AutoTaskName
    r := RunWait(A_ComSpec ' /c schtasks /query /tn "' AutoTaskName '" >nul 2>&1', , "Hide")
    return (r = 0)
}

; 创建 / 删除 提权自启计划任务
;  用计划任务而非启动文件夹，是因为它支持 /rl highest（最高权限）且开机不弹 UAC。
ToggleAutoTask() {
    global AutoTaskName
    if AutoTaskExists() {
        RunWait(A_ComSpec ' /c schtasks /delete /tn "' AutoTaskName '" /f >nul 2>&1', , "Hide")
        ; 退回普通自启，保证"关掉提权"不会变成"完全没有自启"
        SetTimer(MakeStartupLink, -500)
        BuildTrayMenu()
        try TrayTip(L("tip_task_off"), AppName, 1)
        SetTimer(HideRemind, -6000)
        return
    }
    ; /tr 的值里，路径用单引号包起来（schtasks 的规矩），外层才用双引号
    q := Chr(34), sq := Chr(39)
    tr := q sq A_AhkPath sq " " sq A_ScriptFullPath sq q
    cmd := 'schtasks /create /tn "' AutoTaskName '" /tr ' tr ' /sc onlogon /rl highest /f /delay 0000:10'
    try {
        Run('*RunAs ' A_ComSpec ' /c ' cmd)   ; 创建需要授权，弹一次 UAC
        ; ★ 计划任务是【提权版】自启，必须把启动文件夹里的普通快捷方式删掉。
        ;   否则开机会起来两个实例：普通那个后启动的话，
        ;   会以 #SingleInstance Force 顶掉管理员实例 —— 提权白做，
        ;   Ctrl+Alt+F9 又拉不起客户端了。（v1.21 修复）
        try FileDelete(A_Startup "\CNCS.lnk")
        ; schtasks /create 是异步跑的，立刻查状态可能还没建好，
        ; 菜单会误显示成"关" —— 延后 2 秒再刷新一次
        SetTimer(BuildTrayMenu, -2000)
        try TrayTip(L("tip_task_on"), AppName, 1)
        SetTimer(HideRemind, -10000)
    } catch {
        try TrayTip(L("err_task_fail"), AppName, 3)
        SetTimer(HideRemind, -8000)
    }
}

; 启动 5 秒后拉起客户端（若它还没在跑）
AutoOpenClient() {
    global g_confirmed
    if !ProcessExist(ClientExe) {
        ; ★ 自动拉起失败【必须让用户知道】。
        ;   否则脚本在托盘跑着、客户端却没起来，用户完全无感知，
        ;   只会觉得"这软件没用"。（v1.21 修复）
        if !LaunchClient(true) {
            try TrayTip(L("err_launch", ClientPath), AppName, 3)
            SetTimer(HideRemind, -12000)
        }
    }
    SaveWasStopped(false)    ; 已经开起来了，"上次关过"的标记该清掉
    g_confirmed := true      ; 走到这里说明已确认在校（记住了 / 刚拉起）
}

; ============ 上次被你自己关掉 → 开机问一句 ============
;  长期工作模式的第二条规则，取的是中间路线：
;    · 直接拉回来？你明明关了它，很烦人
;    · 完全不问？  又太死板，等于退化成纯手动
;  所以弹个小窗，由你一句话决定。
AskReopen() {
    global g_confirmed, g_stopped
    if ProcessExist(ClientExe)          ; 已经在跑 → 不用问
        return
    if (g_confirmed || g_stopped)       ; 本次已确认 / 本次刚手动停过
        return

    kOpen := KeyName(Hotkey_OpenClient)
    g := Gui("+AlwaysOnTop", L("ask_re_title"))
    g.SetFont("s10", "Microsoft YaHei")
    g.Add("Text", "x20 y18 w400", L("ask_re_body", kOpen))
    bOpen  := g.Add("Button", "x66 y+18 w110 h30 Default", L("btn_open"))
    bLater := g.Add("Button", "x+16 w150 h30", L("btn_later", kOpen))
    ; 把 Gui 对象当参数传进去 —— 这样就不用再多一个全局变量（少一处出错点）
    bOpen.OnEvent("Click", (*) => AskReopenDone(g, true))
    bLater.OnEvent("Click", (*) => AskReopenDone(g, false))
    g.OnEvent("Close", (*) => AskReopenDone(g, false))
    g.OnEvent("Escape", (*) => AskReopenDone(g, false))
    g.Show("AutoSize Center")
}

; doOpen=true → 打开，并恢复"以后自动开"；false → 保持关闭，按 Ctrl+Alt+F9 随叫随到
AskReopenDone(g, doOpen) {
    SaveWasStopped(!doOpen)
    try g.Destroy()
    if doOpen
        OpenClient()      ; 复用 Ctrl+Alt+F9 那套：拉起 + 记住在校
}

; 启动后没有自动拉起时，定时问一句"要不要按 Ctrl+Alt+F9"
; 按了 Ctrl+Alt+F9 就立刻停；一直没按 → 提醒到次数上限就不打扰了
ShowPressTip() {
    global g_confirmed, g_remindCount, g_stopped
    ; 已确认在校 / 用户主动停了 → 收工，并把循环定时器关掉
    if g_confirmed || g_stopped {
        SetTimer(ShowPressTip, 0)
        return
    }
    ; 账号都还没填 → 先让用户按 Ctrl+Alt+F7，别两个提示一起糊上去
    ; ★ 这里【必须自己排下一次定时器】再 return。
    ;   启动时排的是一次性定时器（-RemindF9First），跑完就没了；
    ;   若此刻直接 return，链子就断了 —— 用户后来填了账号，
    ;   却再也收不到"要不要按 Ctrl+Alt+F9"的提醒。（v1.21 修复）
    if (ReadIni("Account", "User", "") = "") {
        SetTimer(ShowPressTip, RemindF9Every)
        return
    }

    g_remindCount++
    try {
        if (g_remindCount >= RemindF9Times) {
            ; 最后一次：语气收一下，说明不再打扰了
            TrayTip(L("tip_press_last", KeyName(Hotkey_OpenClient)), AppName, 1)
            SetTimer(HideRemind, -12000)
            SetTimer(ShowPressTip, 0)   ; 到此为止
            return
        }
        TrayTip(L("tip_press", KeyName(Hotkey_OpenClient)), AppName, 1)
        SetTimer(HideRemind, -10000)
    }
    ; ★ 切成【循环】定时器（正数=反复，负数=只跑一次）
    ;   用循环而不是每次手动排下一次，好处是：中途 return 也不会把链子断掉
    SetTimer(ShowPressTip, RemindF9Every)
}

; 提权被取消时的提示：说明后果 + 给出补救入口
ShowAdminTip() {
    try {
        TrayTip(L("tip_admin_needed"), AppName, 1)
        SetTimer(HideRemind, -12000)
    }
}

; 确认在校：按 Ctrl+Alt+F9 / 点托盘菜单时调用
ConfirmOnCampus() {
    global g_confirmed
    g_confirmed := true
    SetTimer(ShowPressTip, 0)   ; 确认了就别再提醒了
    if RememberOnCampus
        SaveOnCampus()      ; 记忆模式开 → 记下来，以后开机自动干活
}

; 读 / 写"在校"状态（存在 account.ini 的 [State] 段）
IsOnCampus() {
    return ReadIni("State", "OnCampus", "0") = "1"
}
SaveOnCampus() {
    WriteIni("State", "OnCampus", "1")
}

; 读 / 写"上次是不是你自己关掉的"（同样存在 [State] 段）
; 这个标记是长期工作模式的关键：
;   关过 → 下次开机【不擅自拉起】，先问一句（AskReopen）
;   没关 → 下次开机照常自动打开
WasStopped() {
    return ReadIni("State", "WasStopped", "0") = "1"
}
SaveWasStopped(v) {
    WriteIni("State", "WasStopped", v ? "1" : "0")
}

; 忘记"在校"状态（回家了、或换网络环境时用它）
ResetOnCampus() {
    global g_confirmed
    WriteIni("State", "OnCampus", "0")
    SaveWasStopped(false)   ; 环境都变了，"上次关过"这事也一笔勾销
    g_confirmed := false
    try ProcessClose(ClientExe)
    try {
        TrayTip(L("tip_reset", KeyName(Hotkey_OpenClient)), AppName, 1)
        SetTimer(HideRemind, -6000)
    }
}

; 首次提醒：还没设过账号
ShowFirstRemind() {
    try TrayTip(L("tip_noset", KeyName(Hotkey_SetAccount)), AppName, 1)
}

; ============ 按键说明弹窗（首次运行 / 托盘菜单可再看）============
ShowKeyGuide() {
    global g_guideOpen, g_guideGui
    if g_guideOpen
        return
    g_guideOpen := true

    kSet := KeyName(Hotkey_SetAccount)
    kOpen := KeyName(Hotkey_OpenClient)

    tip := L("guide_body", AppVer, kSet, kOpen)

    g := Gui("+AlwaysOnTop", L("guide_title", AppVer))
    g.SetFont("s10", "Microsoft YaHei")
    g.Add("Text", "x18 y16 w440", tip)
    btn := g.Add("Button", "x180 y+14 w120 h30 Default", L("btn_ok"))
    g_guideGui := g
    btn.OnEvent("Click", (*) => CloseKeyGuide())
    g.OnEvent("Close", (*) => CloseKeyGuide())
    g.OnEvent("Escape", (*) => CloseKeyGuide())
    g.Show("AutoSize Center")
}

CloseKeyGuide() {
    global g_guideOpen, g_guideGui
    try g_guideGui.Destroy()
    g_guideOpen := false
    WriteIni("State", "SeenGuide", "1")   ; 记住看过，以后不再弹
}

; 让气泡自己消失，不一直挂着
HideRemind() {
    try TrayTip()
}

; 快捷键（按上面配置区 Hotkey_SetAccount / Hotkey_Quit 注册）
; 改成空字符串即可禁用，不会占用任何按键
RegisterHotkey(Hotkey_SetAccount, (*) => AskAccount())
RegisterHotkey(Hotkey_OpenClient, (*) => OpenClient())
RegisterHotkey(Hotkey_Quit, (*) => ExitApp())

; ============ 注册热键：字母键自动兼容大小写 ============
;  为什么要这样：AHK 里【大写字母 = 要同时按 Shift】。
;    ^!s = Ctrl+Alt+S
;    ^!S = Ctrl+Alt+Shift+S     ← 这是【另一个】热键
;  所以只注册 ^!s 的话，你开着 CapsLock、或者顺手按住 Shift 再按 S，
;  它就【不响应】了 —— 明明看着是同一个键，就因为大小写失灵。
;
;  这里对字母键【自动注册两份】：不带 Shift + 带 Shift。
;  于是无论你现在是中文输入法还是英文、按的是 s 还是 S，都认。
;
;  非字母键（F7、数字、Enter 之类）不受影响，原样注册。
RegisterHotkey(hk, cb) {
    if (hk = "")
        return

    ; 主键 = 去掉修饰符号后剩下的部分
    key := hk
    key := StrReplace(key, "^")
    key := StrReplace(key, "!")
    key := StrReplace(key, "+")
    key := StrReplace(key, "#")

    ; 只有【单个字母】且【配置里没显式写 Shift】才补注册大写版
    if (StrLen(key) = 1 && RegExMatch(key, "^[a-zA-Z]$") && !InStr(hk, "+")) {
        base := SubStr(hk, 1, StrLen(hk) - 1)   ; 修饰前缀（去掉主键）
        lower := StrLower(key)
        try
            Hotkey(base . lower, cb)            ; Ctrl+Alt+S
        try
            Hotkey(base . "+" . lower, cb)      ; Ctrl+Alt+Shift+S
        return
    }
    try
        Hotkey(hk, cb)
}

; ============ 打开客户端 ============
OpenClient() {
    ; 你主动按 Ctrl+Alt+F9 / 点菜单 = 明确表示要用 -> 拉起客户端并开始干活
    global g_stopped, g_launchFail, g_closeAt
    g_stopped := false       ; 主动要用 → 解除"停止"状态
    g_closeAt := 0           ; 清掉"客户端被关"的观察计时，重新计
    SaveWasStopped(false)    ; ★ 记下来：这次是你要开的，下次开机照常自动开
    g_launchFail := 0        ; 重新给机会
    if !LaunchClient()
        MsgBox(L("err_launch", ClientPath), AppName, 48)
    ConfirmOnCampus()      ; 记忆模式开的话，顺便记住"在校"
}

; ============ 停止客户端（本次不再自动拉起）============
;  想断网 / 不想让客户端挂着时用：关掉它，并且不自动拉回来。
;  要重新用，按 Ctrl+Alt+F9 或点托盘「打开客户端」即可。
StopClient() {
    global g_stopped
    g_stopped := true
    SaveWasStopped(true)     ; ★ 持久记住：下次开机【问一句】，不再自作主张开
    try ProcessClose(ClientExe)
    try {
        TrayTip(L("tip_stopped", KeyName(Hotkey_OpenClient)), AppName, 1)
        SetTimer(HideRemind, -6000)
    }
}

; ============ 后台自动处理 ============
CheckWindows(*) {
    ; ★ g_clientSeen / g_closeAt 必须在这里声明！
    ;   AHK v2 是"假定局部"：函数里只要对某变量【赋过值】，
    ;   它在整个函数内就是【局部】的，后面的【读取】也读局部 ——
    ;   于是读到"未赋值"，直接抛 UnsetItemError，定时器整个崩掉。
    ;   本函数每秒都在跑，崩了就等于脚本彻底不工作。（v1.21 修复）
    global g_idle, g_period, g_confirmed, g_stopped, g_launchFail, g_lastLaunch
    global g_clientSeen, g_closeAt, g_calm
    ; 快速预判：无目标窗口直接返回（极省资源）
    ; 按进程名判断：弹窗标题是"提示""警告"等也不会漏
    ; ★ 最后那个 ClientPromptExist() 是 v1.21 补的：
    ;   客户端可能【整个缩在托盘里、一个窗口都不显示】，
    ;   而它弹的「已在线60分钟」提示框又【不属于】主进程 ——
    ;   于是前面三个条件全不成立，函数直接 return，
    ;   那个提示框就永远没人去点。（真机就是这么漏的）
    if !WinExist("ahk_exe " ClientExe)
        && !((ClientTitle != "") && WinExist(ClientTitle))
        && !WinExist("网络选择")
        && !ClientPromptExist() {
        if ProcessExist(ClientExe) {
            ; 进程还在（窗口可能只是最小化/没标题）→ 算它在跑，清掉"消失计时"
            g_clientSeen := true
            g_closeAt := 0
        } else {
            ; ── 先判定：是不是你手动关掉的 ──────────────────
            ; 只有三个条件同时成立才算数：
            ;   ① 之前真的跑起来过（从"有"到"无"才是被关，不是一直没开）
            ;   ② 你没点过「停止客户端」（那是明确的停，走另一条路）
            ;   ③ 消失持续超过了宽限期
            ; 给宽限是因为：客户端自己更新/重启会短暂消失，
            ; 等一会儿它自己回来了，脚本就不打扰你。
            if (g_clientSeen && !g_stopped) {
                if (g_closeAt = 0) {
                    g_closeAt := A_TickCount        ; 第一次发现没了，开始观察
                } else if (A_TickCount - g_closeAt > CloseGraceSec * 1000) {
                    ; 超过宽限还没回来 → 认定是你关的，此后不再自作主张拉起
                    g_stopped := true
                    try {
                        TrayTip(L("tip_userclosed", KeyName(Hotkey_OpenClient)), AppName, 1)
                        SetTimer(HideRemind, -6000)
                    }
                }
            }
            ; 客户端整个没在跑 → 过一会儿帮你重新拉起来（可关，见 AutoStartClient）
            ; ★ 三个前提，缺一不可：
            ;     ① 已确认在校（没确认就绝不会擅自帮你开）
            ;     ② 不是你主动停的 / 不是刚被你关掉的
            ;     ③ 连续失败不到 3 次（多半是路径写错了，别一直刷屏）
            if (AutoStartClient && g_confirmed && !g_stopped && g_launchFail < 3) {
                if (A_TickCount - g_lastLaunch > LaunchCooldown) {
                    LaunchClient(true)
                    g_lastLaunch := A_TickCount
                }
            }
        }
        g_idle++
        if (g_idle > 20 && g_period != IdleEvery) {
            SetTimer(CheckWindows, IdleEvery)
            g_period := IdleEvery
        }
        return
    }
    ; 走到这里说明客户端窗口在 → 标记"跑起来过"，并清掉消失计时
    g_clientSeen := true
    g_closeAt := 0
    g_idle := 0
    ; 刚从空闲切回来（窗口刚出现）→ 立刻恢复快扫
    if (g_calm < CalmAfter && g_period != BusyEvery) {
        SetTimer(CheckWindows, BusyEvery)
        g_period := BusyEvery
    }

    busy := false   ; 本轮有没有"要处理的目标"（用于稳态降频）

    for id in CollectClientWindows() {
        try title := WinGetTitle(id)
        catch
            continue
        if (title = "")
            continue
        ; 按进程名识别：弹窗标题可能是"提示""警告"等，只看标题会漏
        if !IsClientWindow(id, title)
            continue
        idStr := "ahk_id " id
        texts := GetWinText(id)

        ; A. 各类提示弹窗（断线/异常/已在线/超时/失败…）-> 点"确定"
        needOk := false
        isDrop := false
        for w in OkWords {
            if InStr(texts, w) {
                needOk := true
                break
            }
        }
        ; 只有【真断线类】才算"掉过线"（v1.21 修复）
        ;  「已在线60分钟」「在线时长」这类只是时长提醒，根本没掉线，
        ;  记成掉线的话，下次登录会误飘一句"已自动重连"。
        if needOk {
            for w in DropWords {
                if InStr(texts, w) {
                    isDrop := true
                    break
                }
            }
        }
        if needOk || InStr(title, "网络选择") {
            busy := true
            ClickOk(idStr, isDrop)
            continue
        }
        ; B. 登录界面 -> 填号/勾选/登录
        if InStr(texts, "密码") || HasCtrl(id, "Edit2") {
            busy := true
            HandleLogin(idStr, texts)
        }
    }

    ; ── 稳态降频 ──────────────────────────────────────────
    ;  登录成功后窗口一直挂着，此时其实【没活可干】，
    ;  每秒扫一遍纯属浪费。连续 CalmAfter 轮没活 → 降到 3 秒一次；
    ;  一旦出现弹窗（busy）立刻恢复 1 秒快扫，响应速度不受影响。
    if busy {
        g_calm := 0
        ; ★ 立刻恢复快扫（v1.21 修复）
        ;   旧写法只把 g_calm 清零、不动定时器，要等【下一轮】开头
        ;   才切回 BusyEvery —— 稳态是 3 秒一轮，等于弹窗出现后
        ;   最多要等 3 秒才开始处理，慢一拍。
        ;   这里直接切，响应速度不受降频影响。
        if (g_period != BusyEvery) {
            SetTimer(CheckWindows, BusyEvery)
            g_period := BusyEvery
        }
    } else {
        if (g_calm < CalmAfter)
            g_calm++
        if (g_calm >= CalmAfter && g_period != CalmEvery) {
            SetTimer(CheckWindows, CalmEvery)
            g_period := CalmEvery
        }
    }
}

; ============ 关掉客户端自己弹的"文档"窗口 ============
;  部分 Drcom 客户端启动时会自己打开一个"文档"文件夹窗口（资源管理器）。
;  这是客户端自带的行为，脚本管不了它弹，但可以帮你关掉。
;
;  ★ 三重保险，防止误关你自己开的文件夹：
;    ① 窗口类必须是资源管理器（CabinetWClass / ExploreWClass）
;    ② 只在【刚拉起客户端后 DocGraceSec 秒】内有效
;    ③ 每次拉起只关一次（g_docClosed 标记）
CloseClientDocWindow() {
    global g_launchTick, g_docClosed
    if !CloseClientDoc
        return
    if (g_launchTick = 0)
        return
    ; ★ 本次拉起已经关过一次了，别再关（v1.21 修复）
    ;   旧版只【写】了 g_docClosed 却从没【读】它 ——
    ;   注释里写着"只关一次"，实际并没有这道闸。
    if g_docClosed
        return
    ; 超出时间窗 → 不关（这时候出现的"文档"窗口多半是你自己开的）
    if (A_TickCount - g_launchTick > DocGraceSec * 1000)
        return
    closed := 0
    try {
        for id in WinGetList(ClientDocTitle) {
            try cls := WinGetClass(id)
            catch
                continue
            ; 只认资源管理器窗口，别把别的东西关了
            if (cls != "CabinetWClass" && cls != "ExploreWClass")
                continue
            try WinClose("ahk_id " id)
            closed++
            break        ; 每次只关一个，够用了
        }
    }
    if (closed > 0) {
        g_docClosed := true
        try {
            TrayTip(L("tip_docclosed", ClientDocTitle), AppName, 2)
            SetTimer(HideRemind, -5000)
        }
    }
}

; 把 AHK 热键写法转成给人看的文字（^2 -> Ctrl+2，F7 -> F7，^!s -> Ctrl+Alt+S）
KeyName(hk) {
    if (hk = "")
        return "（已禁用）"
    s := ""
    if InStr(hk, "^")
        s .= "Ctrl+"
    if InStr(hk, "!")
        s .= "Alt+"
    if InStr(hk, "+")
        s .= "Shift+"
    if InStr(hk, "#")
        s .= "Win+"
    key := StrReplace(hk, "^")
    key := StrReplace(key, "!")
    key := StrReplace(key, "+")
    key := StrReplace(key, "#")
    ; ★ 单个字母键显示成【大写】（v1.21）
    ;   因为注册时已经把『不带 Shift』和『带 Shift』两个版本都注册了，
    ;   y 和 Y 都认，所以显示上统一写成 Ctrl+Alt+Y，不用标 Shift。
    ;   只转"单个字母"，不影响 F7 / 数字 / Enter 这类键名。
    if (StrLen(key) = 1 && RegExMatch(key, "^[a-zA-Z]$"))
        key := StrUpper(key)
    return s key
}

; 客户端弹的【通用提示框】是否存在（「提示」「警告」「错误」…）
;  ★ 为什么要单独判：这类弹窗常常【不属于】客户端主进程
;    （自己另起一个进程弹出来），按进程名抓不到；
;    标题又只是"提示"两个字，按学校名也抓不到。
;  ★ 必须带上 ahk_class #32770（Windows 标准对话框）：
;    否则会把浏览器标签页、编辑器里带"提示"二字的窗口全算进来，
;    白白让脚本没法进入空闲省电。
;  ★ 先查进程再查窗口：客户端没跑就直接 false，省掉 6 次 WinExist。
ClientPromptExist() {
    if !ProcessExist(ClientExe)
        return false
    for pt in PromptTitles {
        try {
            if WinExist(pt " ahk_class #32770")
                return true
        }
    }
    return false
}

; 收集本轮要处理的窗口
; ★ 优先【按进程】取（系统级过滤，一次拿到），
;   而不是一上来就 WinGetList() 遍历【全部】窗口再逐个比对 ——
;   能走到这里说明客户端进程在，它的窗口基本都能一次取全。
;   开着几十个窗口时，这个差别很明显。（v1.21 优化）
CollectClientWindows() {
    ids := []
    seen := Map()
    try {
        for id in WinGetList("ahk_exe " ClientExe) {
            seen[id] := 1
            ids.Push(id)
        }
    }
    ; ★ 兜底（v1.21 修复）：极少数客户端的弹窗【不属于】主进程
    ;   （自己另起一个进程），按进程名就取不到它。
    ;   旧写法是"只有上面一个都没取到时，才遍历全部窗口按标题补"——
    ;   于是主进程有窗口、弹窗却在别的进程时，兜底根本不触发，
    ;   弹窗被漏掉，脚本一直不点它。
    ;   现在改成【每轮都按标题补一次】，并且用 WinGetList(标题)
    ;   让系统去过滤（而不是遍历全部窗口再逐个比对），
    ;   开销跟按进程取差不多，但不会再漏。
    if (ClientTitle != "") {
        try {
            for id in WinGetList(ClientTitle) {
                if !seen.Has(id) {
                    seen[id] := 1
                    ids.Push(id)
                }
            }
        }
    }
    try {
        for id in WinGetList("网络选择") {
            if !seen.Has(id) {
                seen[id] := 1
                ids.Push(id)
            }
        }
    }
    ; ★ 兜底：标题是「提示」「警告」这类通用词的弹窗（v1.21 补）
    ;   「已在线60分钟」那种框就是这么漏掉的 —— 它不带学校名、
    ;   也可能不是主进程弹的，只能按通用标题把它捞进来。
    ;   （认定条件的严格过滤在 IsClientWindow 里做：必须是 #32770）
    for pt in PromptTitles {
        try {
            ; ★ 直接把 ahk_class 写进 WinTitle，让【系统】去过滤 ——
            ;  比起先捞回一堆窗口再逐个比类名，开销小得多。
            for id in WinGetList(pt " ahk_class #32770") {
                if !seen.Has(id) {
                    seen[id] := 1
                    ids.Push(id)
                }
            }
        }
    }
    return ids
}

; 判断窗口是否属于校园网客户端（优先按进程名，标题兜底）
IsClientWindow(winId, title) {
    try {
        if InStr(WinGetProcessName(winId), ClientExeBase)
            return true
    }
    if InStr(title, ClientTitle) || InStr(title, "网络选择")
        return true
    ; ★ 兜底：标题是「提示」「警告」这类通用词的【标准对话框】（v1.21 补）
    ;   必须是 #32770（MessageBox 的窗口类）才认 ——
    ;   这样浏览器标签页、编辑器里那些带"提示"二字的窗口不会被拉进来。
    try {
        if InStr(WinGetClass(winId), "#32770") {
            for pt in PromptTitles {
                if InStr(title, pt)
                    return true
            }
        }
    }
    return false
}

; 取窗口文本：可见用快方式，最小化才用慢的控件枚举
GetWinText(id) {
    if WinGetMinMax(id) != -1 {
        try
            t := WinGetText(id)
        catch
            t := ""
        if (t != "")
            return t
    }
    return GetCtrlTexts(id)
}

GetCtrlTexts(winId) {
    txt := ""
    try
        for h in WinGetControlsHwnd(winId)
            try txt .= ControlGetText(h) "`n"
    return txt
}

; 窗口若是最小化状态，把它恢复出来，但【不激活】
; SW_SHOWNOACTIVATE = 8：窗口显示，但焦点留在你当前正在用的软件上
; 这样既能让 ControlClick 稳定生效，又不会打断你打游戏 / 打字
EnsureNotMinimized(idStr) {
    if !EnsureVisible
        return false
    try {
        if WinGetMinMax(idStr) = -1 {          ; -1 = 已最小化
            DllCall("ShowWindow", "Ptr", WinGetID(idStr), "Int", 8)
            Sleep(120)
            return true
        }
        ; 有些客户端藏得很深（不可见但未最小化），也一并显示出来
        if !(WinGetStyle(idStr) & 0x10000000) {  ; WS_VISIBLE
            DllCall("ShowWindow", "Ptr", WinGetID(idStr), "Int", 8)
            Sleep(120)
            return true
        }
    }
    return false
}

; 重连成功提示（右下角飘一句，不弹窗、不抢焦点）
NotifyBack() {
    global g_netWasDown
    if !NotifyReconnect
        return
    if !g_netWasDown
        return
    g_netWasDown := false
    try {
        TrayTip(L("tip_reconn"), AppName, 1)
        SetTimer(HideRemind, -4000)   ; 4 秒后自动收掉
    }
}

HasCtrl(winId, classNN) {
    try {
        ControlGetHwnd(classNN, "ahk_id " winId)
        return true
    } catch
        return false
}

; ============ 登录界面处理 ============
HandleLogin(idStr, texts) {
    ; 已登录标志 -> 不动
    if (OnlineWords != "" && RegExMatch(texts, "(" OnlineWords ")"))
        return

    cur := ReadAccount(idStr)
    pwd := ReadPassword(idStr)

    ; ① 界面已有账号 -> 记住并直接登录
    if Trim(cur) != "" {
        if IsValidUser(cur)
            WriteIniIf("Account", "User", cur)     ; 变了才写，别每秒都写
        if IsRealPwd(pwd)
            WriteIniIf("Account", "Pass", pwd)
        EnsureCheck(idStr)
        ClickLogin(idStr)
        return
    }
    ; ② 账号为空 -> 用记住的自动填
    savedUser := ReadIni("Account", "User", "")
    savedPass := ReadIni("Account", "Pass", "")
    if (savedUser = "")
        return
    if (savedPass = "") {
        AskAccount(true)    ; true=自动触发，带冷却，不会刷屏
        return
    }
    FillAccount(idStr, savedUser, savedPass)
    EnsureCheck(idStr)
    ClickLogin(idStr)
}

FillAccount(idStr, user, pass) {
    EnsureNotMinimized(idStr)
    try
        ControlSetText(user, "Edit1", idStr)
    catch
        try ControlSetText(user, "ComboBox1", idStr)
    Sleep(150)
    try
        ControlSetText(pass, "Edit2", idStr)
    catch {
        try ControlClick("Edit2", idStr)
        Sleep(100)
        try ControlSend(pass, "Edit2", idStr)
    }
    Sleep(200)
}

ReadAccount(idStr) {
    v := ""
    try v := ControlGetText("Edit1", idStr)
    catch
        try v := ControlGetText("ComboBox1", idStr)
    return v
}
ReadPassword(idStr) {
    v := ""
    try v := ControlGetText("Edit2", idStr)
    return v
}
IsValidUser(u) {
    return RegExMatch(u, "^\d{5,20}$")     ; 纯数字账号
}
IsRealPwd(p) {
    return (p != "" && !RegExMatch(p, "^\*+$") && StrLen(p) <= 32)
}

; 勾选"记住密码""自动登录"（已勾绝不动）
EnsureCheck(idStr) {
    for lb in ["记住密码", "自动登录"] {
        try {
            if ControlGetChecked(lb, idStr) = 0 {
                ControlClick(lb, idStr)
                Sleep(150)
            }
        }
    }
}

; 点"确定"（带冷却）
ClickOk(idStr, isDrop := true) {
    global g_lastOk, g_netWasDown
    if (A_TickCount - g_lastOk < OkCooldown)
        return
    EnsureNotMinimized(idStr)
    try ControlClick("确定", idStr)
    catch
        try ControlClick("Button1", idStr)
    g_lastOk := A_TickCount
    if isDrop
        g_netWasDown := true  ; 刚点了断线/异常弹窗，等重连成功后提示一次
}

; 点"登录"（带冷却）
ClickLogin(idStr) {
    global g_lastLogin
    if (A_TickCount - g_lastLogin < LoginCooldown)
        return
    EnsureNotMinimized(idStr)
    try ControlClick("登录", idStr)
    catch
        try ControlClick("Button1", idStr)
    g_lastLogin := A_TickCount
    NotifyBack()              ; 若这次是在断线之后点的登录 -> 飘一句"已重连"
}

; ============ Ini 读写（全程容错）============
ReadIni(sec, key, def := "") {
    try
        return IniRead(SaveFile, sec, key, def)
    catch
        return def
}
WriteIni(sec, key, val) {
    try IniWrite(val, SaveFile, sec, key)
}
; 只在值【真的变了】才落盘
; ★ HandleLogin 每秒都被主循环调用一次，里面无条件 WriteIni 的话，
;   就等于每秒重写一遍 account.ini —— 一整天下来几万次无谓写盘，
;   既耗 SSD 又完全没必要（绝大多数时候值根本没变）。（v1.21 优化）
WriteIniIf(sec, key, val) {
    if (ReadIni(sec, key, "") = val)
        return false
    WriteIni(sec, key, val)
    return true
}

; ============ 设置账号密码（Ctrl+Alt+F7 / 缺密码自动弹）============
AskAccount(auto := false) {
    global g_askOpen, g_askGui, g_askEdU, g_askEdP, g_lastAsk
    if g_askOpen
        return
    ; ★ 自动触发（密码没填）时必须加冷却！
    ;   HandleLogin 是每 1 秒跑一次的，密码为空就会每秒弹一次窗，
    ;   关了又弹、关了又弹，根本没法用。（v1.21 修复）
    ;   手动按热键调用时不设限（auto=false）。
    if (auto && A_TickCount - g_lastAsk < AskCooldown)
        return
    g_lastAsk := A_TickCount
    g_askOpen := true
    g := Gui("+AlwaysOnTop +ToolWindow", L("acct_title"))
    g.SetFont("s10", "Microsoft YaHei")
    g.Add("Text", "x16 y16", L("acct_user"))
    edU := g.Add("Edit", "x70 y12 w210", ReadIni("Account", "User", ""))
    g.Add("Text", "x16 y48", L("acct_pass"))
    edP := g.Add("Edit", "x70 y44 w210 Password", ReadIni("Account", "Pass", ""))
    g.Add("Text", "x16 y80 cGray", L("acct_hint"))
    btn := g.Add("Button", "x70 y108 w100 Default", L("btn_save"))
    g_askGui := g
    g_askEdU := edU
    g_askEdP := edP
    btn.OnEvent("Click", (*) => SaveAccount())
    g.OnEvent("Close", (*) => CloseAskAccount())
    g.Show("AutoSize Center")
}

; 点「保存」：把账号密码写进 account.ini
SaveAccount(*) {
    global g_askOpen, g_askGui, g_askEdU, g_askEdP
    WriteIni("Account", "User", g_askEdU.Value)
    WriteIni("Account", "Pass", g_askEdP.Value)
    g_askOpen := false
    if IsObject(g_askGui)
        g_askGui.Destroy()
}

; 直接关掉设置窗口
; ★ 必须 Destroy：AHK v2 的 Close 默认只是【隐藏】不销毁，
;   不手动销毁的话，每弹一次就留一个隐藏窗口，越堆越多。（v1.21 修复）
CloseAskAccount(*) {
    global g_askOpen, g_askGui
    g_askOpen := false
    if IsObject(g_askGui)
        g_askGui.Destroy()
}

; ============ 关于本工具（署名）============
ShowAbout() {
    global g_aboutOpen, g_aboutGui
    if g_aboutOpen
        return
    g_aboutOpen := true
    g := Gui("+AlwaysOnTop +ToolWindow", L("about_title", AppName))
    g.SetFont("s11 Bold", "Microsoft YaHei")
    g.Add("Text", "w460 Center", AppName "  " AppVer)
    g.SetFont("s9 Norm", "Microsoft YaHei")
    g.Add("Text", "w460 Center cGray", "Campus Network Connection System")
    g.Add("Text", "w460 Center cGray", L("about_sub"))
    g.Add("Text", "w460", L("about_body"))
    btn := g.Add("Button", "w100 Center Default", L("btn_good"))
    g_aboutGui := g
    btn.OnEvent("Click", (*) => CloseAbout())
    g.OnEvent("Close", (*) => CloseAbout())
    g.Show("AutoSize Center")
}

; 关掉「关于」窗口
CloseAbout(*) {
    global g_aboutOpen, g_aboutGui
    g_aboutOpen := false
    if IsObject(g_aboutGui)
        g_aboutGui.Destroy()
}

; ==================================================================
;  ==================== 界面语言包（中文 / English）====================
; ==================================================================
; 原则：只翻译「脚本显示给你看的界面文字」。
;   匹配校园网弹窗的关键词（断开 / 密码 / 登录 / 确定 …）一律保持原样 ——
;   那是客户端自己的语言，翻译了反而抓不到弹窗。
; ==================================================================
LoadLang(which) {
    global Lang, T
    Lang := which
    T := Map()
    if (which = "en") {
        ; ── English ──
        T["menu_open"]     := "Open Campus Client ({1})"
        T["menu_setacct"]  := "Set Account ({1})"
        T["menu_stop"]     := "Stop Client (ask me next boot)"
        T["menu_guide"]    := "Key Guide"
        T["menu_reset"]    := "Re-detect (Forget State)"
        T["menu_more"]     := "More Settings"
        T["menu_lang"]     := "Language: {1}"
        T["menu_about"]    := "About"
        T["menu_quit"]     := "Exit"
        T["menu_uninst"]   := "Uninstall (remove shortcuts & autostart)"
        T["menu_admin"]    := "Restart as Administrator (UAC fix)"
        T["menu_autotask"] := "Autostart via Task: {1}"
        T["err_uac"]       := "Client did not start`nProbably blocked by UAC.`n`nTray menu - Restart as Administrator, then press {1}"
        T["tip_already_admin"] := "Already running as Administrator"
        T["err_admin_fail"] := "Could not restart as Administrator.`nThe UAC prompt was cancelled."
        T["tip_admin_needed"] := "Running WITHOUT Administrator rights`n(the UAC prompt was cancelled)`n`n`nThe client may fail to start, and auto-login may not click.`n`nTray menu - Restart as Administrator"
        T["tip_task_on"]   := "Autostart task created`nIt will now start as Administrator at login,`nwith no UAC prompt."
        T["tip_task_off"]  := "Autostart task removed`nNow it starts the normal way again."
        T["err_task_fail"] := "Could not create the task.`nThe UAC prompt was cancelled."
        T["state_on"]      := "ON (remember after one press)"
        T["state_off"]     := "OFF (normal autostart)"
        T["lang_zh"]       := "Chinese"
        T["lang_en"]       := "English"

        T["tip_restore"]   := "Restored your saved account"
        T["tip_noset"]     := "Account not set yet`nPress {1} once, then fully automatic"
        T["tip_press"]      := "Campus network is not connected yet`nPress {1} to start the client, or ignore this"
        T["tip_press_last"] := "Still not connected`nNo more reminders after this one.`n`nPress {1} any time you want to connect."
        T["tip_reset"]     := "Reset to unconfirmed`nWill ask again next boot; press {1} to use"
        T["tip_reconn"]    := "Campus network reconnected`nThe disconnect popup was handled"
        T["tip_lang"]      := "Language switched to {1}"
        T["err_launch"]    := "Failed to open client, check path:`n{1}"
        T["err_nopath"]    := "Client path does not exist:`n{1}`n`nFix ClientPath in 自动校园网.ahk"
        T["tip_stopped"]   := "Client stopped`nNext boot it will ASK before opening.`nPress {1} any time you want it."
        T["tip_userclosed"] := "You closed the client`nAuto-restart paused for now.`nPress {1} to open it again."
        T["tip_docclosed"] := "Closed the {1} window`nIt was opened by the campus network client itself"

        T["uninst_title"]  := "Uninstall / Clean Up"
        T["uninst_ask"]    := "This will remove the desktop / Start menu / autostart shortcuts.`n`n"
            . "The program files and your saved account are NOT deleted.`n`n"
            . "* To remove it completely: move out the files YOU`n"
            . "  changed (account.ini, edited scripts), then delete`n"
            . "  everything else. A fresh archive next time will`n"
            . "  replace the rest automatically.`n`n"
            . "Continue?"
        T["uninst_done"]   := "Cleaned {1} item(s).`n`n"
            . "Shortcuts and autostart are gone - it will not start by itself.`n`n"
            . "----------------------------------------`n"
            . "* To remove it completely - no need to delete one by one:`n`n"
            . "   Move out the files YOU changed (account.ini, edited`n"
            . "   scripts), then just delete the whole folder.`n`n"
            . "   Next time you unzip a fresh archive, everything else`n"
            . "   gets replaced automatically.`n`n"
            . "   (No need to rename files or fix the dot.)"
        T["uninst_none"]   := "Nothing found to clean.`n`n"
            . "No CNCS shortcuts or autostart entries were detected."
        T["uninst_exit"]   := "Exit the program now too?`n`n"
            . "(Choose No to keep it running in the tray.)"

        T["guide_title"]   := "CNCS {1} - Key Guide"
        T["guide_body"]    := "Welcome to CNCS {1}`n"
            . "It runs quietly in the background - just remember two keys:`n`n"
            . "----------------------------------------`n`n"
            . "  [{2}] Set Account`n"
            . "        * Press this first *`n"
            . "        Enter account & password once, then it is automatic.`n`n"
            . "  [{3}] Open Campus Client`n"
            . "        Press it = tell it: I need campus net now`n"
            . "        Pressed     -> opens client, auto-login starts`n"
            . "        Not pressed -> client stays closed (other network)`n"
            . "        Memory ON (default): one press is enough forever`n`n"
            . "----------------------------------------`n`n"
            . "Press {2} now to fill in your account,`n"
            . "then forget about it.`n`n"
            . "Right-click the tray icon to see this again."
        T["btn_ok"]        := "Got it"

        ; ── 上次被你自己关掉 → 开机问一句（长期工作模式）──
        T["ask_re_title"]  := "Campus Client"
        T["ask_re_body"]   := "You closed the campus client last time."
            . "`n`nOpen it now?"
            . "`n`n  * Open  -> opens now, and auto-opens at next boot again"
            . "`n  * Later  -> stays closed; press {1} whenever you need it"
        T["btn_open"]      := "Open"
        T["btn_later"]     := "Later ({1})"

        T["acct_title"]    := "Campus Account"
        T["acct_user"]     := "Account:"
        T["acct_pass"]     := "Password:"
        T["acct_hint"]     := "Saved in account.ini - delete before sharing (cncs.id is safe)"
        T["btn_save"]      := "Save"

        T["about_title"]   := "About {1}"
        T["about_sub"]     := "AutoHotkey v2 - Windows campus auto-login"
        T["about_body"]    := "`n"
            . "----------------------------------------`n"
            . "[Two Common Questions]`n`n"
            . " 1) Archive name has no dot?`n"
            . "     e.g. CNCS_v121.zip -- don't panic, this is NORMAL.`n"
            . "     Windows or IM apps may drop the dot when transferring.`n`n"
            . "     * No need to fix it. Just unzip -- the contents`n"
            . "       are exactly the same.`n`n"
            . " 2) Want to uninstall? Easy`n"
            . "     Move out the files YOU changed (account.ini etc.),`n"
            . "     then just delete the rest. Next time you unzip a`n"
            . "     fresh archive, it replaces everything else.`n"
            . "     Just want no autostart? Tray menu - Autostart.`n"
            . "----------------------------------------`n`n"
            . "[Credits]`n`n"
            . "  Summer Calico`n"
            . "  Jiangxi Univ. of Sci. and Tech. - Telecom`n`n"
            . "  x`n`n"
            . "  Yuanbao AI`n"
            . "  Tencent Intelligent Assistant`n`n"
            . "        -- Jointly Made --`n"
            . "----------------------------------------`n`n"
            . "  Thanks for using! May your campus net never drop.`n`n"
            . "  ! Security: password saved in plain text in`n"
            . "    account.ini - delete it before sharing!`n"
        T["btn_good"]      := "OK"
    } else {
        ; ── 中文 ──
        T["menu_open"]     := "打开校园网客户端 ({1})"
        T["menu_setacct"]  := "设置账号密码 ({1})"
        T["menu_stop"]     := "停止客户端（下次开机先问我）"
        T["menu_guide"]    := "查看按键说明"
        T["menu_reset"]    := "重新识别（忘记在校状态）"
        T["menu_more"]     := "更多设置"
        T["menu_lang"]     := "语言 / Language：{1}"
        T["menu_about"]    := "关于本工具"
        T["menu_quit"]     := "退出脚本"
        T["menu_uninst"]   := "卸载清理（删快捷方式+自启）"
        T["menu_admin"]    := "以管理员权限重启（解决 UAC 拦截）"
        T["menu_autotask"] := "开机自启：计划任务提权 / {1}"
        T["err_uac"]       := "客户端没能启动`n多半被 UAC（用户账户控制）拦住了`n`n右键托盘 → 以管理员权限重启，再按 {1}"
        T["tip_already_admin"] := "已经是管理员权限在运行了"
        T["err_admin_fail"] := "没能以管理员权限重启。`n刚才的 UAC 授权框被取消了。"
        T["tip_admin_needed"] := "当前不是管理员权限运行`n（你刚才取消了 UAC 授权）`n`n可能导致：客户端拉不起来、自动登录点不动。`n`n补救：右键托盘 → 以管理员权限重启"
        T["tip_task_on"]   := "计划任务已创建`n以后开机会以管理员权限自动启动，且不再弹 UAC。"
        T["tip_task_off"]  := "计划任务已删除`n恢复成普通的开机自启方式。"
        T["err_task_fail"] := "创建计划任务失败。`n刚才的 UAC 授权框被取消了。"
        T["state_on"]      := "开（按一次管以后）"
        T["state_off"]     := "关（普通开机自启）"
        T["lang_zh"]       := "中文"
        T["lang_en"]       := "English"

        T["tip_restore"]   := "已自动恢复上次保存的账号配置"
        T["tip_noset"]     := "还没设置账号密码呢`n按 {1} 填一次，之后就全自动了"
        T["tip_press"]     := "还没打开校园网客户端`n在学校要用校园网 → 按 {1}"
        T["tip_press_last"] := "还没连接校园网`n这是最后一次提醒，之后不再打扰。`n`n想用的时候随时按 {1} 就行。"
        T["tip_reset"]     := "已重置为「未确认」`n下次开机重新识别，要用校园网按 {1}"
        T["tip_reconn"]    := "校园网已自动重连`n刚才断线的弹窗已经被处理掉了"
        T["tip_lang"]      := "界面语言已切换为 {1}"
        T["err_launch"]    := "打开客户端失败，请检查路径：`n{1}"
        T["err_nopath"]    := "客户端路径不存在：`n{1}`n`n请改 自动校园网.ahk 里的 ClientPath"
        T["tip_stopped"]   := "已停止客户端`n下次开机不会直接开，会先问你一句`n要用时随时按 {1}"
        T["tip_userclosed"] := "检测到你关闭了客户端`n本次不再自动拉起`n想再用随时按 {1}"
        T["tip_docclosed"] := "已关掉客户端自己弹出的「{1}」窗口"

        T["uninst_title"]  := "卸载清理"
        T["uninst_ask"]    := "即将删除：桌面快捷方式、开始菜单项、开机自启项。`n`n"
            . "★ 程序本体和你的账号密码【不会】被删除。`n`n"
            . "★ 想彻底不用了？更简单：`n"
            . "   把【除压缩包外】你自己动过的文件移出去`n"
            . "   （account.ini、改过的脚本等），`n"
            . "   其余直接删掉就行。`n"
            . "   下次下载新压缩包解压，会自动替换那些文件。`n`n"
            . "确定要清理吗？"
        T["uninst_done"]   := "已清理 {1} 处。`n`n"
            . "快捷方式和开机自启都没了，以后它不会自己启动。`n`n"
            . "───────────────────────`n"
            . "★ 想彻底卸载？其实不用一个个删：`n`n"
            . "   把【除压缩包外】你自己动过的文件移出去`n"
            . "   （account.ini、改过的脚本等），`n"
            . "   其余的文件夹直接删掉就行。`n`n"
            . "   下次下载新压缩包一解压，`n"
            . "   那些没动过的文件会自动被替换回来。`n`n"
            . "   （不用手动去改文件名、不用改小数点。）"
        T["uninst_none"]   := "没有找到可清理的东西。`n`n"
            . "桌面、开始菜单、开机自启里都没有 CNCS 的快捷方式。"
        T["uninst_exit"]   := "要同时退出本程序吗？`n`n"
            . "（选「否」则继续在托盘里跑着。）"

        T["guide_title"]   := "CNCS {1} · 按键说明"
        T["guide_body"]    := "欢迎使用 CNCS {1}`n"
            . "它在后台自己跑，你只需记住两个按键：`n`n"
            . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━`n`n"
            . "  【{2}】 填账号密码`n"
            . "            ★ 第一次用，先按它 ★`n"
            . "            填一次账号和密码，之后全自动登录。`n`n"
            . "  【{3}】 打开校园网客户端`n"
            . "            按它 = 告诉脚本「这次我要用校园网」`n"
            . "            按了 → 打开客户端、开始自动登录`n"
            . "            没按 → 客户端保持不开（在用别的网）`n"
            . "            记忆模式（默认开）：按一次管以后`n`n"
            . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━`n`n"
            . "现在就可以先按 {2} 把账号填好，`n"
            . "之后什么都不用管了。`n`n"
            . "右下角托盘图标右键，还能再看本窗口。"
        T["btn_ok"]        := "知道了"

        ; ── 上次被你自己关掉 → 开机问一句（长期工作模式）──
        T["ask_re_title"]  := "校园网客户端"
        T["ask_re_body"]   := "上次是您自己关闭了校园网客户端。"
            . "`n`n现在要打开它吗？"
            . "`n`n  · 打开 → 立刻打开，以后开机照常自动开"
            . "`n  · 暂不 → 保持关闭，需要时按 {1}"
        T["btn_open"]      := "打开"
        T["btn_later"]     := "暂不（{1}）"

        T["acct_title"]    := "校园网账号设置"
        T["acct_user"]     := "账号："
        T["acct_pass"]     := "密码："
        T["acct_hint"]     := "仅存本机 account.ini，转发前请先删除此文件（cncs.id 不用删）"
        T["btn_save"]      := "保存"

        T["about_title"]   := "关于 {1}"
        T["about_sub"]     := "AutoHotkey v2 · Windows 校园网自动登录"
        T["about_body"]    := "`n"
            . "────────────────────────────────────────`n"
            . "【两个常见疑惑】`n`n"
            . " ① 压缩包文件名没有小数点？`n"
            . "     比如 CNCS_v121.zip —— 别慌，这是【正常现象】。`n"
            . "     Windows 或微信/QQ 传文件时，小数点可能被弄丢。`n`n"
            . "     ★ 不用改它，直接解压就能用，`n"
            . "       里面的内容跟带小数点的【一模一样】。`n`n"
            . " ② 想卸载？很简单`n"
            . "     把【除压缩包外】你自己动过的文件移出去就行`n"
            . "     （比如 account.ini、改过的脚本），`n"
            . "     下次下载新压缩包解压，会自动替换掉其余文件。`n"
            . "     只想停掉开机自启：右键托盘 → 开机自启 关掉即可。`n"
            . "────────────────────────────────────────`n`n"
            . "【制作团队】`n`n"
            . "  夏日花猫  ·  Summer Calico`n"
            . "  江西赣南科技学院 · 通信`n`n"
            . "  ×`n`n"
            . "  元宝AI（Yuanbao）`n"
            . "  腾讯智能助手`n`n"
            . "        —— 联合制作 ——`n"
            . "────────────────────────────────────────`n`n"
            . "  感谢使用！愿你的校园网永不掉线。`n`n"
            . "  ⚠️ 安全提醒：账号密码明文保存在`n"
            . "     account.ini，转发前务必删除！`n"
        T["btn_good"]      := "好"
    }
}

; 取一条界面文字，{1}{2}{3} 会被替换成参数
L(key, p1 := "", p2 := "", p3 := "") {
    global T
    v := T.Has(key) ? T[key] : key
    if (p1 != "")
        v := StrReplace(v, "{1}", p1)
    if (p2 != "")
        v := StrReplace(v, "{2}", p2)
    if (p3 != "")
        v := StrReplace(v, "{3}", p3)
    return v
}

; 重建托盘菜单（切语言 / 提权自启开关变化时会整体重建）
; ── 托盘菜单：按使用频率分两层（v1.21 精简）──────────────
;  以前 13 项平铺一层，右键出来一大条 ——
;  可你日常真正会点的就「打开 / 停止 / 设账号」这三样，
;  其余（改语言、看说明、卸载…）一年也点不了两次，
;  却天天挤在菜单里挡视线。
;  所以：常用的留在一级，偶尔用的收进「更多设置」子菜单。
BuildTrayMenu() {
    global Lang
    A_TrayMenu.Delete()

    ; ══ 一级：日常会点的 ══
    menuOpen := L("menu_open", KeyName(Hotkey_OpenClient))
    A_TrayMenu.Add(menuOpen, (*) => OpenClient())
    A_TrayMenu.Add(L("menu_stop"), (*) => StopClient())
    A_TrayMenu.Add(L("menu_setacct", KeyName(Hotkey_SetAccount)), (*) => AskAccount())
    A_TrayMenu.Add()
    ; 开机自启带状态显示，留在一级方便一眼确认开没开
    A_TrayMenu.Add(L("menu_autotask", AutoTaskExists() ? L("state_on") : L("state_off")), (*) => ToggleAutoTask())

    ; ══ 二级：偶尔才用的，收进子菜单 ══
    more := Menu()
    more.Add(L("menu_guide"), (*) => ShowKeyGuide())
    more.Add(L("menu_reset"), (*) => ResetOnCampus())
    more.Add(L("menu_admin"), (*) => RestartAsAdmin())
    more.Add()
    more.Add(L("menu_lang", (Lang = "zh") ? L("lang_zh") : L("lang_en")), (*) => SwitchLang())
    more.Add(L("menu_about"), (*) => ShowAbout())
    more.Add(L("menu_uninst"), (*) => UninstallCleanup())
    A_TrayMenu.Add()
    A_TrayMenu.Add(L("menu_more"), more)

    A_TrayMenu.Add()
    A_TrayMenu.Add(L("menu_quit"), (*) => ExitApp())
    A_TrayMenu.Default := menuOpen
}

; ============ 卸载清理：删掉桌面 / 开始菜单 / 开机自启 ============
;  想"真的不用它了"时用：一键把外面那些入口清干净，
;  这样它以后不会自己开机启动。程序本体和账号密码不动 ——
;  真要彻底删除，手动删掉整个文件夹即可。
UninstallCleanup() {
    ; 先确认一次，防止右键误点到
    if (MsgBox(L("uninst_ask"), L("uninst_title"), 36) != "Yes")
        return

    n := RemoveEntries()

    if (n > 0)
        MsgBox(L("uninst_done", n), L("uninst_title"), 64)
    else
        MsgBox(L("uninst_none"), L("uninst_title"), 64)

    ; 清完再问要不要退出（选否就继续在托盘跑着）
    if (MsgBox(L("uninst_exit"), L("uninst_title"), 36) = "Yes")
        ExitApp()
}

; 真正干活的：找 .lnk 判断目标是不是指向本程序，是就删
; 判据用【快捷方式指向的目标】，不靠文件名 ——
; 这样你把快捷方式改个名，它照样认得出来。
RemoveEntries() {
    n := 0
    seen := Map()

    dirs := []
    dirs.Push(A_Desktop)
    dirs.Push(A_Startup)
    try dirs.Push(A_StartMenu)
    try dirs.Push(A_DesktopCommon)
    try dirs.Push(A_StartupCommon)
    try dirs.Push(A_StartMenuCommon)
    ; OneDrive 接管桌面的情况（很多人的"桌面"其实在 OneDrive 里）
    od := ""
    try od := EnvGet("OneDrive")
    if (od != "")
        dirs.Push(od "\Desktop")

    shell := ""
    try shell := ComObject("WScript.Shell")

    for dir in dirs {
        if (dir = "" || !DirExist(dir))
            continue
        Loop Files dir "\*.lnk", "F" {
            f := A_LoopFileFullPath
            if seen.Has(f)
                continue
            seen[f] := 1

            del := false
            ; ① 文件名带 CNCS 就直接认定
            if InStr(A_LoopFileName, "CNCS")
                del := true

            ; ② 否则读快捷方式的目标路径来判断（公共目录常没权限，失败就算了）
            if (!del && shell != "") {
                try {
                    tgt := shell.CreateShortcut(f).TargetPath
                    if (tgt != "") {
                        if (InStr(tgt, A_ScriptFullPath) || InStr(tgt, A_ScriptDir "\") || InStr(tgt, "CNCS"))
                            del := true
                    }
                }
            }

            if del {
                try {
                    FileDelete(f)
                    n++
                }
            }
        }
    }

    ; 提权自启计划任务（优先级高于启动文件夹，必须一并清掉，
    ; 否则点完"卸载清理"，开机它照样自己起来 —— v1.21 修复）
    if AutoTaskExists() {
        RunWait(A_ComSpec ' /c schtasks /delete /tn "' AutoTaskName '" /f >nul 2>&1', , "Hide")
        n++
    }

    ; 顺带清一下注册表里的开机自启（旧版本可能用过，或你自己加过）
    try {
        key := "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run"
        Loop Reg key, "V" {
            v := ""
            try v := RegRead(key, A_LoopRegName)
            if (v != "" && (InStr(v, "CNCS") || InStr(v, A_ScriptFullPath))) {
                try {
                    RegDelete(key, A_LoopRegName)
                    n++
                }
            }
        }
    }

    return n
}

; 语言切换：中文 <-> English
SwitchLang() {
    global Lang
    Lang := (Lang = "zh") ? "en" : "zh"
    LoadLang(Lang)
    WriteIni("Config", "Lang", Lang)
    BuildTrayMenu()
    try {
        TrayTip(L("tip_lang", (Lang = "zh") ? L("lang_zh") : L("lang_en")), AppName, 1)
        SetTimer(HideRemind, -4000)
    }
}
